from flask import Blueprint, render_template, redirect, url_for, request, session, flash, jsonify
from flask_login import login_required
from app.decorators import role_required
from app.models import MikroTikRouter
from app.services.mikrotik_api import MikroTikAPI
from app.forms.hotspot_wizard import (
    SelectRouterForm, AddressPoolForm, AssignIPForm,
    ServerProfileForm, HotspotServerForm, UserProfileForm
)

wizard_bp = Blueprint("hotspot_wizard", __name__, url_prefix="/hotspot-wizard")

STEPS = {
    1: "Select Router",
    2: "Configure Address Pool",
    3: "Assign IP to Interface",
    4: "Create Server Profile",
    5: "Create Hotspot Server",
    6: "Add User Profile",
    7: "Confirm & Finish"
}

@wizard_bp.route("/step/<int:step>", methods=["GET", "POST"])
@login_required
@role_required("admin")
def hotspot_wizard(step):
    session.setdefault("hotspot_config", {})
    config = session["hotspot_config"]
    form = None
    template = "admin/hotspot_wizard.html"

    if step == 1:
        form = SelectRouterForm()
        form.router_id.choices = [(r.id, f"{r.name} ({r.ip_address})") for r in MikroTikRouter.query.all()]
        if form.validate_on_submit():
            config["router_id"] = form.router_id.data
            session["hotspot_config"] = config
            return redirect(url_for("admin.hotspot_wizard.hotspot_wizard", step=2))

    elif step == 2:
        router = MikroTikRouter.query.get(config.get("router_id"))
        api = MikroTikAPI(ip=router.ip_address, username=router.api_username, password=router.api_password, port=router.api_port)
        if not api.connect(router):
            flash("❌ Could not connect to router.", "danger")
            return redirect(url_for("admin.hotspot_wizard.hotspot_wizard", step=1))

        form = AddressPoolForm()
        if form.validate_on_submit():
            config["pool_name"] = form.pool_name.data
            config["pool_range"] = form.pool_range.data
            session["hotspot_config"] = config
            return redirect(url_for("admin.hotspot_wizard.hotspot_wizard", step=3))

    elif step == 3:
        router = MikroTikRouter.query.get(config.get("router_id"))
        api = MikroTikAPI(ip=router.ip_address, username=router.api_username, password=router.api_password, port=router.api_port)
        if not api.connect(router):
            flash("❌ Could not connect to router.", "danger")
            return redirect(url_for("admin.hotspot_wizard.hotspot_wizard", step=1))

        form = AssignIPForm()
        try:
            interfaces = api.api.get_resource("/interface/ethernet").get()
            form.interface.choices = [(iface.get("name"), iface.get("name")) for iface in interfaces]
        except Exception:
            form.interface.choices = []

        if form.validate_on_submit():
            config["interface"] = form.interface.data
            config["hotspot_ip"] = form.hotspot_ip.data
            session["hotspot_config"] = config
            return redirect(url_for("admin.hotspot_wizard.hotspot_wizard", step=4))

    elif step == 4:
        router = MikroTikRouter.query.get(config.get("router_id"))
        api = MikroTikAPI(ip=router.ip_address, username=router.api_username, password=router.api_password, port=router.api_port)
        if not api.connect(router):
            flash("❌ Could not connect to router.", "danger")
            return redirect(url_for("admin.hotspot_wizard.hotspot_wizard", step=1))

        form = ServerProfileForm()
        if form.validate_on_submit():
            config["profile_name"] = form.profile_name.data
            config["dns_name"] = form.dns_name.data
            config["rate_limit"] = form.rate_limit.data
            config["smtp_server"] = form.smtp_server.data.strip() if hasattr(form, "smtp_server") and form.smtp_server.data else None
            config["html_directory"] = form.html_directory.data.strip() if hasattr(form, "html_directory") and form.html_directory.data else "hotspot"
            session["hotspot_config"] = config
            return redirect(url_for("admin.hotspot_wizard.hotspot_wizard", step=5))

    elif step == 5:
        router = MikroTikRouter.query.get(config.get("router_id"))
        api = MikroTikAPI(ip=router.ip_address, username=router.api_username, password=router.api_password, port=router.api_port)
        if not api.connect(router):
            flash("❌ Could not connect to router.", "danger")
            return redirect(url_for("admin.hotspot_wizard.hotspot_wizard", step=1))

        form = HotspotServerForm()
        if form.validate_on_submit():
            session["hotspot_config"] = config
            return redirect(url_for("admin.hotspot_wizard.hotspot_wizard", step=6))

    elif step == 6:
        router = MikroTikRouter.query.get(config.get("router_id"))
        api = MikroTikAPI(ip=router.ip_address, username=router.api_username, password=router.api_password, port=router.api_port)
        if not api.connect(router):
            flash("❌ Could not connect to router.", "danger")
            return redirect(url_for("admin.hotspot_wizard.hotspot_wizard", step=1))

        form = UserProfileForm()
        if form.validate_on_submit():
            config["user_profile_name"] = form.user_profile_name.data
            config["shared_users"] = form.shared_users.data
            config["user_rate_limit"] = form.user_rate_limit.data
            session["hotspot_config"] = config
            return redirect(url_for("admin.hotspot_wizard.hotspot_wizard", step=7))

    elif step == 7:
        if request.method == "POST":
            router = MikroTikRouter.query.get(config.get("router_id"))
            api = MikroTikAPI(ip=router.ip_address, username=router.api_username, password=router.api_password, port=router.api_port)
            if api.connect(router):
                try:
                    api.create_ip_pool(config["pool_name"], config["pool_range"])
                    api.assign_ip_to_interface(config["interface"], config["hotspot_ip"])
                    api.create_hotspot_profile(
                        name=config["profile_name"],
                        hotspot_address=config["hotspot_ip"],
                        dns_name=config["dns_name"],
                        rate_limit=config.get("rate_limit"),
                        smtp_server=config.get("smtp_server"),
                        html_directory=config.get("html_directory", "hotspot")
                    )
                    api.create_hotspot_server(config["interface"], config["profile_name"], config["pool_name"])
                    api.create_user_profile(
                        config["user_profile_name"],
                        shared_users=config["shared_users"],
                        rate_limit=config["user_rate_limit"]
                    )
                    flash("✅ Hotspot setup successfully completed.", "success")
                    session.pop("hotspot_config", None)
                    return redirect(url_for("admin.routers.manage_routers"))
                except Exception as e:
                    flash(f"❌ Setup failed: {str(e)}", "danger")
            else:
                flash("❌ Could not connect to router.", "danger")
        template = "admin/hotspot_summary.html"

    return render_template(template, form=form, step=step, step_title=STEPS.get(step, "Hotspot Setup"), config=config)

# 🔄 API: Live interface list for AJAX
@wizard_bp.route("/api/<int:router_id>/interfaces")
@login_required
@role_required("admin")
def get_router_interfaces(router_id):
    router = MikroTikRouter.query.get_or_404(router_id)
    api = MikroTikAPI(ip=router.ip_address, username=router.api_username, password=router.api_password, port=router.api_port)
    if not api.connect(router):
        return jsonify({"status": "error", "message": "Could not connect"}), 500
    try:
        interfaces = api.api.get_resource("/interface/ethernet").get()
        return jsonify({
            "status": "success",
            "interfaces": [iface.get("name", "") for iface in interfaces]
        })
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500
