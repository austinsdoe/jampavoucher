from app.cli.router_cli import sync_routers_command
app.cli.add_command(sync_routers_command)
